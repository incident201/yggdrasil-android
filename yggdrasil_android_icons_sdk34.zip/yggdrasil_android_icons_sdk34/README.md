# Yggdrasil VPN Android icons

Готовый набор ресурсов для Android-проекта с compileSdk / Android SDK 34.

## Что внутри

- `app/src/main/res/mipmap-*/ic_launcher.png` — обычные launcher icons для старых Android.
- `app/src/main/res/mipmap-*/ic_launcher_round.png` — round launcher icons.
- `app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml` — adaptive icon.
- `app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml` — adaptive round icon.
- `app/src/main/res/mipmap-*/ic_launcher_foreground.png` — foreground layer для adaptive icon.
- `app/src/main/res/mipmap-*/ic_launcher_monochrome.png` — monochrome layer для themed icons Android 13+.
- `app/src/main/res/drawable/ic_launcher_background.xml` — фон adaptive icon.
- `app/src/main/res/values/ic_launcher_colors.xml` — цвет фона.
- `app/src/main/res/drawable-*/ic_stat_yggdrasil.png` — опциональная маленькая белая иконка для уведомлений / foreground service.
- `playstore/playstore-icon.png` — 512x512 иконка для Google Play / metadata.

## Как подключить

Скопируй папку `app/src/main/res` из архива в свой Android-проект с заменой файлов.

В `AndroidManifest.xml` у application должны быть указаны:

```xml
android:icon="@mipmap/ic_launcher"
android:roundIcon="@mipmap/ic_launcher_round"
```

Для уведомлений / foreground service можно использовать:

```kotlin
.setSmallIcon(R.drawable.ic_stat_yggdrasil)
```
